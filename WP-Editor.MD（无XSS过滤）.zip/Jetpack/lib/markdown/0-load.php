<?php

if ( ! class_exists( 'MarkdownExtra_Parser' ) )
	jetpack_require_lib_editormd( 'markdown/extra' );

jetpack_require_lib_editormd( 'markdown/gfm' );
